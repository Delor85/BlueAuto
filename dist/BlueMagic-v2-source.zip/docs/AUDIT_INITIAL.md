# Audit de la version reçue — août 2026

## Dépôt GitHub

Le dépôt `Delor85/BlueAuto` contient une ébauche Android, pas une application complète prête au terrain.

- `MainActivity` lance le code avec `Intent.ACTION_CALL`, mais n’interagit pas avec l’étape PIN ;
- aucune classe `AccessibilityService` ;
- aucun service Android persistant ;
- le récepteur SMS est dynamique et disparaît avec l’activité ;
- le PIN et la clé d’appairage sont dans des `SharedPreferences` ordinaires ;
- l’application conserve l’écran allumé en permanence ;
- `minSdk 26` exclut Android 6 et 7 sans nécessité ;
- un second `MainActivity.java` à la racine utilise un autre package et n’appartient pas au module Android ;
- le workflow appelle un Gradle système non verrouillé et le dépôt ne contient pas de wrapper.

## ZIP `htdocs`

### Risques critiques

- `api.php` accepte tout le monde (`Access-Control-Allow-Origin: *`) et ne vérifie aucun appareil ;
- n’importe quel client peut déposer un code USSD arbitraire pour n’importe quel nœud ;
- une commande est marquée `TERMINE` dès sa lecture, avant même la composition ou le résultat ;
- les fichiers SQLite sont placés dans le dossier web public ;
- aucun verrou transactionnel n’empêche deux Robots de lire le même ordre ;
- aucun identifiant anti-doublon ne protège contre plusieurs pressions ou retries réseau.

### Pannes de code

- `ussdEngine.js` contient une structure d’objet invalide ;
- JavaScript utilise `.contains()` au lieu de `.includes()` ;
- le Java expose `executeUSSD`, tandis que JavaScript appelle aussi `executeUssd` avec une casse différente ;
- le moteur renvoie encore un SMS simulé et non une réponse réelle ;
- `transfer.js` utilise l’ancien préfixe `*150*...*PIN#`, incompatible avec le cahier mis à jour ;
- le PIN est encodé en Base64 (`btoa`), ce qui n’est pas un chiffrement ;
- les transactions et comptes sont stockés dans `localStorage`, donc isolés par téléphone et non fiables pour un ERP ;
- l’interface interroge le serveur toutes les 4 secondes pour le ping, l’état et la commande, ce qui multiplie les requêtes et la consommation.

## Décision de reconstruction

Conserver l’ancien modèle aurait ajouté un service d’accessibilité sur une file non authentifiée et non idempotente, avec un risque direct de double transfert ou d’ordre frauduleux. Le noyau a donc été repris sur quatre bases :

1. intention métier contrôlée par le serveur ;
2. file MySQL transactionnelle avec lease ;
3. automate Android natif persistant ;
4. PIN exclusivement local, vérification stricte du pop-up et preuve opérateur.

Les infrastructures Huawei/ZTE de Camtel ne sont pas appelées directement : sans API ou habilitation opérateur, elles restent hors de portée. Blue Magic agit uniquement sur la SIM autorisée dans le téléphone Robot et sur l’interface Android que l’utilisateur a explicitement configurée.
